<?php
/**
 * Template Name: Schedule Consultation
 * Description: Custom scheduling page for Widespread Custom Landscape & Design.
 */

// Configuration - Update these as needed
$calendar_id  = "YOUR_ID_HERE"; // Replace with your actual Google Calendar schedule ID
$company_name = "Widespread Custom";
$owner_name   = "Matt Jacobsen";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact | <?php echo $company_name; ?> Landscape & Design</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Outfit:wght@500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --khaki-light: #f5f2ed;  /* Light Beige background */
            --khaki-deep: #e8e2d6;   /* Section contrast */
            --slate: #2d3436;        /* Primary Text */
            --accent-green: #7ca18a; /* Sage Green for gradient start */
            --accent-blue: #5b7083;  /* Slate Blue for gradient end */
            --white: #ffffff;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--khaki-light);
            color: var(--slate);
            padding: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 1150px;
            background: var(--white);
            border-radius: 30px;
            display: grid;
            grid-template-columns: 1fr 1.5fr;
            overflow: hidden;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.08);
            border: 1px solid var(--khaki-deep);
        }

        /* Branding Pane */
        .info-side {
            padding: 60px 40px;
            background-color: var(--khaki-deep);
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        h1 {
            font-family: 'Outfit', sans-serif;
            font-size: 2.8rem;
            line-height: 1;
            margin-bottom: 20px;
            color: var(--slate);
        }

        .sub-text {
            font-size: 1.1rem;
            color: #555;
            margin-bottom: 35px;
        }

        /* The Custom Gradient Button */
        .appointment-btn {
            display: inline-block;
            text-decoration: none;
            padding: 16px 32px;
            font-family: 'Outfit', sans-serif;
            font-weight: 500;
            color: white;
            border-radius: 12px;
            background: linear-gradient(to right, var(--accent-green), var(--accent-blue));
            box-shadow: 0 4px 15px rgba(124, 161, 138, 0.3);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            text-align: center;
            border: none;
            cursor: pointer;
        }

        .appointment-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(91, 112, 131, 0.4);
        }

        /* Calendar Pane */
        .calendar-side {
            background: var(--white);
            padding: 20px;
            display: flex;
            flex-direction: column;
        }

        .iframe-wrapper {
            position: relative;
            flex-grow: 1;
            width: 100%;
            height: 100%;
            min-height: 600px;
            border-radius: 20px;
            overflow: hidden;
            border: 1px solid var(--khaki-light);
        }

        iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: none;
        }

        /* Responsive Breakpoints */
        @media (max-width: 992px) {
            .container {
                grid-template-columns: 1fr;
                margin: 20px auto;
            }
            .info-side {
                padding: 40px;
                text-align: center;
            }
            h1 { font-size: 2.2rem; }
            .iframe-wrapper { min-height: 500px; }
        }

        @media (max-width: 480px) {
            body { padding: 10px; }
            .info-side { padding: 30px 20px; }
            .appointment-btn { width: 100%; }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="info-side">
        <p style="text-transform: uppercase; letter-spacing: 2px; font-size: 0.8rem; margin-bottom: 10px; font-weight: 600; color: var(--accent-blue);">
            <?php echo $company_name; ?>
        </p>
        <h1>Schedule Your Consultation</h1>
        <p class="sub-text">Transform your landscape with an onsite visit from <?php echo $owner_name; ?>. Secure your slot using the calendar.</p>
        
        <div>
            <a href="#calendar" class="appointment-btn">60 Min Appointment</a>
        </div>
    </div>

    <div class="calendar-side" id="calendar">
        <div class="iframe-wrapper">
            <iframe src="https://calendar.google.com/calendar/appointments/schedules/<?php echo $calendar_id; ?>?gv=true"></iframe>
        </div>
    </div>
</div>

</body>
</html>